# Risk Register (Template)

Track top risks and de-risk early with “early tests”.

## R01 — <risk title>
- Description:
- Impact: High / Medium / Low
- Likelihood: High / Medium / Low
- Early test / mitigation:
- Owner:
- Status: open / mitigated / accepted

## R02 — ...
