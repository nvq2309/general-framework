# Architecture Decisions (Template)

This file summarizes major decisions and links to ADRs.

## Decisions
- ADR-0001: <title> — <status> — <link>
